  //----------
  // zasilacz
  //----------
  let zXPos = 1250;
  let zYPos = 200;
  let zX = 450;
  let zY = 250;

function blackC() {
  fill(0, 0, 0);
  stroke(0, 0, 0);
  strokeWeight(0);
}


function textS() {
  textSize(15);
  textFont("consolas");
  textAlign(CENTER, CENTER);
  fill("black");
  strokeWeight(0);
}

function setup() {
  createCanvas(0.9*displayWidth, 0.8*displayHeight);
  
  //----------
  // wahadlo
  //----------
  origin = createVector(540, -1000);
  cewkaU = createVector();
  cewkaU2 = createVector();
    
  //----------
  // slidery
  //----------
  let SliderV; 
  sliderV = createSlider(-1.3, 1.3, 0, 0.001);
  sliderV.style("width", "400px")
  sliderV.position(zXPos+25, zYPos+zY-40);
  
}

function draw() {
  background(220);
  textS();
  
  //----------------------------------------
  //miarka
  //----------------------------------------
  let miarkah = 800
  blackC();
  strokeWeight(2);
  line(35, miarkah, 1045, miarkah);
  for (let i = 0; i <= 198; i++) {
    //line(65 + i * 25, miarkah, 65 + i * 25, miarkah-10);
    line(45 + i * 5, miarkah, 45 + i * 5, miarkah-5);
  }
  for (let i = 0; i <= 20; i++) {
    blackC();
    strokeWeight(2);
    line(40 + i * 50, miarkah, 40 + i * 50, miarkah-20);
  }
   for (let i = -10; i <= 10; i++) {
    blackC();
    text(abs(i) * 10, 540 + i * 50, miarkah-30);
  }
  text("[mm]", 50, miarkah+15);
  
  //----------------------------------------
  //magnes
  //----------------------------------------
  fill("gray");
  stroke("gray");
  rect(30, 600, 1200, 150, 0, 0, 10, 0);
  rect(30, 200, 1200, 150, 0, 10, 0, 0);
  rect(1080, 340, 150, 300, 0, 0, 0, 0);
  
  //----------------------------------------
  //cewka
  //----------------------------------------
  let r = random(-0.002, 0.002);
  let cewkaL = 1450;
  let a = 0;
  a = (r*sliderV.value()+sliderV.value())/3.8
  
  cewkaU.x = cewkaL * sin(a) + origin.x;
  cewkaU.y = cewkaL * cos(a) + origin.y;
  
  cewkaU2.x = (cewkaL+500) * sin(a) + origin.x;
  cewkaU2.y = (cewkaL+500) * cos(a) + origin.y;
  
  stroke("black");
  strokeWeight(54);
  line(origin.x, origin.y, cewkaU.x, cewkaU.y);
  stroke("red");
  strokeWeight(0.5);
  line(origin.x, origin.y, cewkaU2.x, cewkaU2.y);
  fill("rgb(184, 115, 51)");
  stroke("rgb(184, 115, 51)");
  strokeWeight(50);
  line(origin.x, origin.y, cewkaU.x, cewkaU.y);
  strokeWeight(0);
  circle(cewkaU.x, cewkaU.y, 50);
  
  //----------------------------------------
  //zasilacz
  //----------------------------------------
  
  fill("rgb(209,206,188)")
  stroke("black")
  strokeWeight(2)
  rect(zXPos, zYPos, zX, zY, 25, 25, 25, 25);
  fill("rgb(0,0,0)")
  rect(zXPos+25, zYPos+50, zX-50, zY-100, 5, 5, 5, 5);
  textSize(60);
  textFont("consolas");
  textAlign(LEFT, CENTER);
  fill("red");
  strokeWeight(0);
  let valV = text(nf(sliderV.value()*16.7, 1,2),zXPos+30,zYPos+90);
  let valA = text(nf(sliderV.value()*16.7, 1,2),zXPos+30,zYPos+160);
  textSize(20);
  textFont("consolas");
  textAlign(LEFT, CENTER);
  fill("white");
  text("V Voltage", zXPos+250, zYPos+90);
  text("A Current[test]", zXPos+250, zYPos+160);
  
  fill("rgb(99,98,93)")
  
  rect(zXPos, zYPos+450, zX, 100, 5, 5, 25, 25);
  fill("black")
  textSize(25);
  textFont("consolas");
  textAlign(CENTER, CENTER);
  fill("black");
  strokeWeight(0);
  text("0", zXPos+90, zYPos+480);
  text("5", zXPos+180, zYPos+480);
  text("15", zXPos+270, zYPos+480);
  text("25", zXPos+350, zYPos+480);
  text("Uzyskana liczba zwojów: "+xX, zXPos+220, zYPos+520);
  if(xX==5){
  fill("black")
  rect(zXPos+80, zYPos+400, 20, 50, 5, 5, 0, 0);
  fill("red")
  rect(zXPos+170, zYPos+400, 20, 50, 5, 5, 0, 0);
  }else if(xX==10){
  fill("black")
  rect(zXPos+170, zYPos+400, 20, 50, 5, 5, 0, 0);
  fill("red")
  rect(zXPos+260, zYPos+400, 20, 50, 5, 5, 0, 0); 
  }else if(xX==15){
  fill("black")
  rect(zXPos+80, zYPos+400, 20, 50, 5, 5, 0, 0);
  fill("red")
  rect(zXPos+260, zYPos+400, 20, 50, 5, 5, 0, 0); 
  }else if(xX==20){
  fill("black")
  rect(zXPos+170, zYPos+400, 20, 50, 5, 5, 0, 0);
  fill("red")
  rect(zXPos+340, zYPos+400, 20, 50, 5, 5, 0, 0); 
  }else if(xX==25){
  fill("black")
  rect(zXPos+80, zYPos+400, 20, 50, 5, 5, 0, 0);
  fill("red")
  rect(zXPos+340, zYPos+400, 20, 50, 5, 5, 0, 0); 
  }else{
  textSize(20);
  text("Nie można uzyskać takiej liczby zwojów", zXPos+225, zYPos+430);}
}
  let xX = 5;
function keyPressed() {
  if (keyCode === RIGHT_ARROW) {
    xX += 5;
  } else if (keyCode === LEFT_ARROW) {
    xX -= 5;
  }
}

